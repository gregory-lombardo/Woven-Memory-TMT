
# GITHUB PUSH INSTRUCTIONS

# 1. Crée repo vide sur github.com/gregory-lombardo/Woven-Memory-TMT (ne coche pas README)

# 2. Dans ton terminal:
cd /chemin/vers/Woven-Memory-TMT
git init
git add .
git commit -m "Initial commit: Woven Memory TMT v1.0 - G=eta*M - Dubious but Falsifiable"
git branch -M main
git remote add origin https://github.com/gregory-lombardo/Woven-Memory-TMT.git
git push -u origin main

# 3. Active Zenodo sync:
- Va sur zenodo.org > Account > GitHub
- Sync le repo > Flip switch ON
- Fais une Release sur GitHub: Releases > Create new release > v1.0.0
- Zenodo va automatiquement créer un DOI permanent

# 4. Ton DOI sera genre 10.5281/zenodo.XXXXXXX - tu le mets dans le papier
