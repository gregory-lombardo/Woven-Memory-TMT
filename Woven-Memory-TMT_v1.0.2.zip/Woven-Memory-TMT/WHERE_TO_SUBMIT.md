
ARXIV SUBMISSION:
- Category: gr-qc + quant-ph
- Title same
- Upload woven_memory.tex + figures/*.png as ancillary
- Comments: 5 pages, 1 figure, code at github.com/gregory-lombardo/Woven-Memory-TMT, falsifiable but dubious
- License: arXiv.org perpetual non-exclusive

OTHER JOURNALS TO TRY (in order of troll level):
1. Foundations of Physics (Springer) - aime les idées folles mais testables
2. International Journal of Theoretical Physics
3. Journal of High Energy Physics (JHEP) - si tu veux viser haut, mais il faut plus de maths
4. Entropy (MDPI) - adore l'info + gravité
5. vixra.org (si arXiv te rejette - archive alternative, pas peer-reviewed mais ça existe)

Ne soumets PAS à PRL/Nature en premier avec ça, ils desk-reject direct. Vise Entropy ou Foundations d'abord.
